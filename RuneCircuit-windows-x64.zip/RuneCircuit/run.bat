@echo off
chcp 65001 >nul
RuneCircuit.exe %*
pause
